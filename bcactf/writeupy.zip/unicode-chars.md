# 􃗁􌲔􇺟􊸉􁫞􄺷􄧻􃄏􊸉 | Crypto

### Solution

From ctf we have got ciphertext.md file.

#### ciphertext.md

```md
"􇺟􊸉􊶬􊸉􃗁 􋄚􆖓􇺟􇺟􄧻 􋄚􆆗􊶬􊸉 􉯓􆖓􌲔 􌲔􃄏" 􆆗􁫞 􇽛􉂫􊸉 􉗽􊸉􆞎􌲔􇽛 􁫞􆆗􇺟􋄚􋐝􊸉 􃗁􊸉􄺷􆖓􃗁􉗽􊸉􉗽 􆞎􉯓 􊸉􇺟􋄚􋐝􆆗􁫞􉂫
􁫞􆆗􇺟􋄚􊸉􃗁 􄧻􇺟􉗽 􁫞􆖓􇺟􋄚􏕈􃗁􆆗􇽛􊸉􃗁 􃗁􆆗􄺷􏟟 􄧻􁫞􇽛􋐝􊸉􉯓, 􃗁􊸉􋐝􊸉􄧻􁫞􊸉􉗽 􆖓􇺟 27 􀴠􌲔􋐝􉯓 1987. 􆆗􇽛 􏕈􄧻􁫞
􏕈􃗁􆆗􇽛􇽛􊸉􇺟 􄧻􇺟􉗽 􃄏􃗁􆖓􉗽􌲔􄺷􊸉􉗽 􆞎􉯓 􁫞􇽛􆖓􄺷􏟟 􄧻􆆗􇽛􏟟􊸉􇺟 􏕈􄧻􇽛􊸉􃗁􌘗􄧻􇺟, 􄧻􇺟􉗽 􏕈􄧻􁫞 􃗁􊸉􋐝􊸉􄧻􁫞􊸉􉗽
􄧻􁫞 􇽛􉂫􊸉 􌶴􆆗􃗁􁫞􇽛 􁫞􆆗􇺟􋄚􋐝􊸉 􌶴􃗁􆖓􌘗 􄧻􁫞􇽛􋐝􊸉􉯓'􁫞 􉗽􊸉􆞎􌲔􇽛 􄧻􋐝􆞎􌲔􌘗, 􏕈􉂫􊸉􇺟􊸉􊶬􊸉􃗁 􉯓􆖓􌲔 􇺟􊸉􊸉􉗽
􁫞􆖓􌘗􊸉􆞎􆖓􉗽􉯓 (1987). 􇽛􉂫􊸉 􁫞􆖓􇺟􋄚 􏕈􄧻􁫞 􄧻 􏕈􆖓􃗁􋐝􉗽􏕈􆆗􉗽􊸉 􇺟􌲔􌘗􆞎􊸉􃗁-􆖓􇺟􊸉 􉂫􆆗􇽛, 􆆗􇺟􆆗􇽛􆆗􄧻􋐝􋐝􉯓
􆆗􇺟 􇽛􉂫􊸉 􌲔􇺟􆆗􇽛􊸉􉗽 􏟟􆆗􇺟􋄚􉗽􆖓􌘗 􆆗􇺟 1987, 􏕈􉂫􊸉􃗁􊸉 􆆗􇽛 􁫞􇽛􄧻􉯓􊸉􉗽 􄧻􇽛 􇽛􉂫􊸉 􇽛􆖓􃄏 􆖓􌶴 􇽛􉂫􊸉
􄺷􉂫􄧻􃗁􇽛 􌶴􆖓􃗁 􌶴􆆗􊶬􊸉 􏕈􊸉􊸉􏟟􁫞 􄧻􇺟􉗽 􏕈􄧻􁫞 􇽛􉂫􊸉 􆞎􊸉􁫞􇽛-􁫞􊸉􋐝􋐝􆆗􇺟􋄚 􁫞􆆗􇺟􋄚􋐝􊸉 􆖓􌶴 􇽛􉂫􄧻􇽛 􉯓􊸉􄧻􃗁.
􆆗􇽛 􊸉􊶬􊸉􇺟􇽛􌲔􄧻􋐝􋐝􉯓 􇽛􆖓􃄏􃄏􊸉􉗽 􇽛􉂫􊸉 􄺷􉂫􄧻􃗁􇽛􁫞 􆆗􇺟 25 􄺷􆖓􌲔􇺟􇽛􃗁􆆗􊸉􁫞, 􆆗􇺟􄺷􋐝􌲔􉗽􆆗􇺟􋄚 􇽛􉂫􊸉
􌲔􇺟􆆗􇽛􊸉􉗽 􁫞􇽛􄧻􇽛􊸉􁫞 􄧻􇺟􉗽 􏕈􊸉􁫞􇽛 􋄚􊸉􃗁􌘗􄧻􇺟􉯓.[6] 􇽛􉂫􊸉 􁫞􆖓􇺟􋄚 􏕈􆖓􇺟 􆞎􊸉􁫞􇽛 􆞎􃗁􆆗􇽛􆆗􁫞􉂫 􁫞􆆗􇺟􋄚􋐝􊸉
􄧻􇽛 􇽛􉂫􊸉 1988 􆞎􃗁􆆗􇽛 􄧻􏕈􄧻􃗁􉗽􁫞.

􇽛􉂫􊸉 􌘗􌲔􁫞􆆗􄺷 􊶬􆆗􉗽􊸉􆖓 􌶴􆖓􃗁 􇽛􉂫􊸉 􁫞􆖓􇺟􋄚 􉂫􄧻􁫞 􆞎􊸉􄺷􆖓􌘗􊸉 􇽛􉂫􊸉 􆞎􄧻􁫞􆆗􁫞 􌶴􆖓􃗁 􇽛􉂫􊸉 "
􃗁􆆗􄺷􏟟􃗁􆖓􋐝􋐝􆆗􇺟􋄚" 􆆗􇺟􇽛􊸉􃗁􇺟􊸉􇽛 􌘗􊸉􌘗􊸉. 􆆗􇺟 2008, 􄧻􁫞􇽛􋐝􊸉􉯓 􏕈􆖓􇺟 􇽛􉂫􊸉 􌘗􇽛􊶬 􊸉􌲔􃗁􆖓􃄏􊸉 􌘗􌲔􁫞􆆗􄺷
􄧻􏕈􄧻􃗁􉗽 􌶴􆖓􃗁 􆞎􊸉􁫞􇽛 􄧻􄺷􇽛 􊸉􊶬􊸉􃗁 􏕈􆆗􇽛􉂫 􇽛􉂫􊸉 􁫞􆖓􇺟􋄚, 􄧻􁫞 􄧻 􃗁􊸉􁫞􌲔􋐝􇽛 􆖓􌶴 􄺷􆖓􋐝􋐝􊸉􄺷􇽛􆆗􊶬􊸉
􊶬􆖓􇽛􆆗􇺟􋄚 􌶴􃗁􆖓􌘗 􇽛􉂫􆖓􌲔􁫞􄧻􇺟􉗽􁫞 􆖓􌶴 􃄏􊸉􆖓􃄏􋐝􊸉 􆖓􇺟 􇽛􉂫􊸉 􆆗􇺟􇽛􊸉􃗁􇺟􊸉􇽛, 􉗽􌲔􊸉 􇽛􆖓 􇽛􉂫􊸉
􃄏􆖓􃄏􌲔􋐝􄧻􃗁 􃄏􉂫􊸉􇺟􆖓􌘗􊸉􇺟􆖓􇺟 􆖓􌶴 􃗁􆆗􄺷􏟟􃗁􆖓􋐝􋐝􆆗􇺟􋄚.[7] 􇽛􉂫􊸉 􁫞􆖓􇺟􋄚 􆆗􁫞 􄺷􆖓􇺟􁫞􆆗􉗽􊸉􃗁􊸉􉗽
􄧻􁫞􇽛􋐝􊸉􉯓'􁫞 􁫞􆆗􋄚􇺟􄧻􇽛􌲔􃗁􊸉 􁫞􆖓􇺟􋄚 􄧻􇺟􉗽 􆆗􇽛 􆆗􁫞 􆖓􌶴􇽛􊸉􇺟 􃄏􋐝􄧻􉯓􊸉􉗽 􄧻􇽛 􇽛􉂫􊸉 􊸉􇺟􉗽 􆖓􌶴 􉂫􆆗􁫞
􋐝􆆗􊶬􊸉 􄺷􆖓􇺟􄺷􊸉􃗁􇽛􁫞.

􆆗􇺟 2019, 􄧻􁫞􇽛􋐝􊸉􉯓 􃗁􊸉􄺷􆖓􃗁􉗽􊸉􉗽 􄧻􇺟􉗽 􃗁􊸉􋐝􊸉􄧻􁫞􊸉􉗽 􄧻 '􃄏􆆗􄧻􇺟􆖓􌶴􆖓􃗁􇽛􊸉' 􊶬􊸉􃗁􁫞􆆗􆖓􇺟 􆖓􌶴 􇽛􉂫􊸉
􁫞􆖓􇺟􋄚 􌶴􆖓􃗁 􉂫􆆗􁫞 􄧻􋐝􆞎􌲔􌘗 􇽛􉂫􊸉 􆞎􊸉􁫞􇽛 􆖓􌶴 􌘗􊸉, 􏕈􉂫􆆗􄺷􉂫 􌶴􊸉􄧻􇽛􌲔􃗁􊸉􁫞 􄧻 􇺟􊸉􏕈 􃄏􆆗􄧻􇺟􆖓
􄧻􃗁􃗁􄧻􇺟􋄚􊸉􌘗􊸉􇺟􇽛.[8]

􁫞􉂫􄧻􌘗􊸉􋐝􊸉􁫞􁫞􋐝􉯓 􄺷􆖓􃄏􆆗􊸉􉗽
􌶴􃗁􆖓􌘗 [􏕈􆆗􏟟􆆗􃄏􊸉􉗽􆆗􄧻'􁫞 􄧻􃗁􇽛􆆗􄺷􋐝􊸉 􆖓􇺟 􇽛􉂫􊸉 􁫞􌲔􆞎􀴠􊸉􄺷􇽛](􉂫􇽛􇽛􃄏􁫞://􊸉􇺟.􏕈􆆗􏟟􆆗􃄏􊸉􉗽􆆗􄧻.􆖓􃗁􋄚/􏕈􆆗􏟟􆆗/􇺟􊸉􊶬􊸉􃗁_􋄚􆖓􇺟􇺟􄧻_􋄚􆆗􊶬􊸉_􉯓􆖓􌲔_􌲔􃄏)

􆞎􄺷􄧻􄺷􇽛􌶴{􁫞􆖓􃗁􃗁􉯓_􏕈􊸉_􃗁􄧻􇺟_􆖓􌲔􇽛_􆖓􌶴_􃗁􌲔􇺟􊸉􁫞_􁫞􀴠􃗁􉂫􏕈􆞎􋄚}
```

After quick look at the content of the file I assume that this is substitution cipher. I know few websites that could
easily break this kind of cipher, but none of them accept unicode chars so I wrote simple python script to deal with it
and replace all unicode to alphabetic chars.

```py
from string import ascii_letters, printable

with open("ciphertext.md", "r") as f:
    cip = f.read()

unique = {}
count = 0

for v in cip:
    if v != ' ' and v != '\n' and v not in printable:
        if v not in unique:
            unique[v] = ascii_letters[count]
            cip = cip.replace(v, unique[v])
            count += 1

print(cip)
```

Running this script resulted with this mess:
```
"abcbd efaag ehcb ifj jk" hl mnb obpjm lhaeqb dbrfdobo pi baeqhln lhaebd gao lfaesdhmbd dhrt glmqbi, dbqbglbo fa 27 ujqi 1987. hm sgl sdhmmba gao kdfojrbo pi lmfrt ghmtba sgmbdvga, gao sgl dbqbglbo gl mnb whdlm lhaeqb wdfv glmqbi'l obpjm gqpjv, snbabcbd ifj abbo lfvbpfoi (1987). mnb lfae sgl g sfdqoshob ajvpbd-fab nhm, hahmhgqqi ha mnb jahmbo thaeofv ha 1987, snbdb hm lmgibo gm mnb mfk fw mnb rngdm wfd whcb sbbtl gao sgl mnb pblm-lbqqhae lhaeqb fw mngm ibgd. hm bcbamjgqqi mfkkbo mnb rngdml ha 25 rfjamdhbl, harqjohae mnb jahmbo lmgmbl gao sblm ebdvgai.[6] mnb lfae sfa pblm pdhmhln lhaeqb gm mnb 1988 pdhm gsgdol.

mnb vjlhr chobf wfd mnb lfae ngl pbrfvb mnb pglhl wfd mnb "dhrtdfqqhae" hambdabm vbvb. ha 2008, glmqbi sfa mnb vmc bjdfkb vjlhr gsgdo wfd pblm grm bcbd shmn mnb lfae, gl g dbljqm fw rfqqbrmhcb cfmhae wdfv mnfjlgaol fw kbfkqb fa mnb hambdabm, ojb mf mnb kfkjqgd knbafvbafa fw dhrtdfqqhae.[7] mnb lfae hl rfalhobdbo glmqbi'l lheagmjdb lfae gao hm hl fwmba kqgibo gm mnb bao fw nhl qhcb rfarbdml.

ha 2019, glmqbi dbrfdobo gao dbqbglbo g 'khgafwfdmb' cbdlhfa fw mnb lfae wfd nhl gqpjv mnb pblm fw vb, snhrn wbgmjdbl g abs khgaf gddgaebvbam.[8]

lngvbqbllqi rfkhbo wdfv [shthkbohg'l gdmhrqb fa mnb ljpubrm](nmmkl://ba.shthkbohg.fde/shth/abcbd_efaag_ehcb_ifj_jk)

prgrmw{lfddi_sb_dga_fjm_fw_djabl_ludnspe}
```

As I mentioned earlier, I know few websites to decode this kind of encryption and [this is one of them](https://planetcalc.com/8047/)
```
"NEVER GONNA GIVE YOU UP" IS THE DEBUT SINGLE RECORDED BY ENGLISH SINGER AND SONGWRITER RICK ASTLEY, RELEASED ON 27 JULY 1987. IT WAS WRITTEN AND PRODUCED BY STOCK AITKEN WATERMAN, AND WAS RELEASED AS THE FIRST SINGLE FROM ASTLEY'S DEBUT ALBUM, WHENEVER YOU NEED SOMEBODY (1987). THE SONG WAS A WORLDWIDE NUMBER-ONE HIT, INITIALLY IN THE UNITED KINGDOM IN 1987, WHERE IT STAYED AT THE TOP OF THE CHART FOR FIVE WEEKS AND WAS THE BEST-SELLING SINGLE OF THAT YEAR. IT EVENTUALLY TOPPED THE CHARTS IN 25 COUNTRIES, INCLUDING THE UNITED STATES AND WEST GERMANY.[6] THE SONG WON BEST BRITISH SINGLE AT THE 1988 BRIT AWARDS.

THE MUSIC VIDEO FOR THE SONG HAS BECOME THE BASIS FOR THE "RICKROLLING" INTERNET MEME. IN 2008, ASTLEY WON THE MTV EUROPE MUSIC AWARD FOR BEST ACT EVER WITH THE SONG, AS A RESULT OF COLLECTIVE VOTING FROM THOUSANDS OF PEOPLE ON THE INTERNET, DUE TO THE POPULAR PHENOMENON OF RICKROLLING.[7] THE SONG IS CONSIDERED ASTLEY'S SIGNATURE SONG AND IT IS OFTEN PLAYED AT THE END OF HIS LIVE CONCERTS.

IN 2019, ASTLEY RECORDED AND RELEASED A 'PIANOFORTE' VERSION OF THE SONG FOR HIS ALBUM THE BEST OF ME, WHICH FEATURES A NEW PIANO ARRANGEMENT.[8]

SHAMELESSLY COPIED FROM [WIKIPEDIA'S ARTICLE ON THE SUBJECT](HTTPS://EN.WIKIPEDIA.ORG/WIKI/NEVER_GONNA_GIVE_YOU_UP)

BCACTF{SORRY_WE_RAN_OUT_OF_RUNES_SJRHWBG}
```

In ctf description is a mentioned that flag is lower case, let's change it quick
```bash
$ python -c 'print("BCACTF{SORRY_WE_RAN_OUT_OF_RUNES_SJRHWBG}".lower())'
bcactf{sorry_we_ran_out_of_runes_sjrhwbg}
```


### Flag

bcactf{sorry_we_ran_out_of_runes_sjrhwbg}

#### Credits

- Writeup by [HuntClauss](https://ctftime.org/user/106464)
- Solved by [HuntClauss](https://ctftime.org/user/106464)
- WaletSec 2021

#### License

**CC BY 4.0** WaletSec + HuntClauss